package application;

public class Programm {

    public static int FeldGroesser;
    public static int Breite;
    public static int Hoeher;

}
