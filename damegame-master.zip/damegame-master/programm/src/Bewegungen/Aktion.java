package Bewegungen;

public enum Aktion {
    KeineAktion, GehtEinFeldWeiter, FresstGegner
}
