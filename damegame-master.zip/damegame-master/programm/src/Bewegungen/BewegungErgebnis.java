package Bewegungen;

import DameSteinen.Steinen;

public class BewegungErgebnis {

    private Steinen steine;

}
