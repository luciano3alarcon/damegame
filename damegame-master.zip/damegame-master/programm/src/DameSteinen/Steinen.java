package DameSteinen;

import Feld.Feld;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;

import static application.Programm.FeldGroesser;

public class Steinen extends StackPane{

    private SteinArt steinArt;

    private double clickX, clickY;
    private double urspruenglichePositionX;
    private double urspruenglichePositionY;

    //Ein Stein braucht Typ und Position
    public Steinen(SteinArt steinArt, int x, int y){
        this.steinArt = steinArt;

        //Stack wird die Klasse extends, damit man setOnMousePressed() verwenden kann.
        //StackPane pane = new StackPane();
        //Stage stage = new Stage();

        //Zuerst wird die Schattierung erstellt.
        //Circle stein = new Circle(FeldGroesser * 0.325, FeldGroesser * 0325);
        Ellipse steinSchatierung = new Ellipse(FeldGroesser * 0.3125, FeldGroesser * 0.26);
        //Farbe setXXX setzt die Farbe für die Schatierung.
        steinSchatierung.setFill(Color.BLACK);
        steinSchatierung.setStroke(Color.BLACK);
        steinSchatierung.setStrokeWidth(FeldGroesser * 0.02);

        //Hier wird ein Stein erstellt. Ein Stein sollte ähnlich Gross
        Ellipse dameStein = new Ellipse(FeldGroesser * 0.3125, FeldGroesser * 0.26);
        if(steinArt == steinArt.Schwarz) dameStein.setFill(Color.valueOf("#2C2C2C"));
        else dameStein.setFill(Color.valueOf("#F5F5F5"));

        dameStein.setStroke(Color.BLACK);
        dameStein.setStrokeWidth(FeldGroesser * 0.02);

        dameStein.setTranslateX((FeldGroesser - FeldGroesser * 0.325 * 2) / 2);
        dameStein.setTranslateY((FeldGroesser -FeldGroesser * 0.26 * 2) / 2);

        //Hier wird Stein und Schattierung zusammengesetzt.
        getChildren().addAll(steinSchatierung, dameStein);


        setOnMousePressed(event -> {
                clickX = event.getSceneX();
                clickY = event.getSceneY();
                });

        //Hier wird der Stein von
        setOnMouseDragged(event -> {
            relocate(event.getSceneX() - clickX + urspruenglichePositionX,
                    event.getSceneY() - clickY + urspruenglichePositionY);
                });
    }

    /* Methode nicht nötig.
    private void setOnMousePressed() {
    }*/

    public void steinBewegung(int x, int y){
        urspruenglichePositionX = x * FeldGroesser;
        urspruenglichePositionY = y * FeldGroesser;
        relocate(urspruenglichePositionX, urspruenglichePositionY);
    }

    public double geturspruenglichePositionX() {
        return urspruenglichePositionX;
    }

    public void seturspruenglichePositionX(double urspruenglichePositionX) {
        this.urspruenglichePositionX = urspruenglichePositionX;
    }

    public double getGeturspruenglichePositionY() {
        return urspruenglichePositionY;
    }

    public void setGeturspruenglichePositionY(double geturspruenglichePositionY) {
        this.urspruenglichePositionY = geturspruenglichePositionY;
    }
}
