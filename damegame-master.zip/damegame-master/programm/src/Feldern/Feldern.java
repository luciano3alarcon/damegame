package Feldern;

import DameSteinen.Steinen;

public class Feldern {

    public Steinen steinen;

}
